package com.akshay.bookAuthorApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookAuthorAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookAuthorAppApplication.class, args);
	}

}
