package com.akshay.bookAuthorApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookAuthorAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
