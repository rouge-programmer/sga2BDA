package com.library.book_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
